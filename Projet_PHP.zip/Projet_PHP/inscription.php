<!--<html>
<head>
<title>Inscription</title>
</head>
<body>
<h1>Créer un nouveau compte personnel afin d'ajouter des news</h1>

include "affiche_utilisateur.php";


<form method="post" action="addSites.php">
<h1>Ajout d'un point de vente</h1>
Nom : <input type="text" size="15" name="nom"><br>
Prénom : <input type="text" size="15" name="prenom"><br>
Adresse mail : <input type="text" size="30" name="email"><br>
Mot de passe : <input type="text" size="30" name="mdp"><br>
Vérification mot de passe : <input type="text" size="30" name="verif_mdp"><br>
<input type="submit" value="Créer le compte"/>
</form>
</body>
</html>

-->

<?php
$id=(isset($_SESSION['id']))?(int)$_SESSION['id']:0;
$nom=(isset($_SESSION['nom']))?$_SESSION['nom']:'';
$prenom=(isset($_SESSION['prenom']))?$_SESSION['prenom']:'';
session_start();
$titre = "Inscription";
include("login.php");
?>


 <style type="text/css">
fieldset { width:30%;
border-radius: 25px;
}
label {
	width:50%;
	display:block;
text-align:left;
}
input[type="submit"]
{
  display: inline-block;
  padding: 15px 25px;
  font-size: 24px;
  cursor: pointer;
  text-align: center;
  text-decoration: none;
  outline: none;
  color: #fff;
  background-color: #4286f4;
  border: none;
  border-radius: 15px;
  box-shadow: 0 9px #999;
}

input[type="submit"]:hover {background-color: #4286f4}

input[type="submit"]:active {
  background-color: ##4286f4;
  box-shadow: 0 5px #666;
  transform: translateY(4px);
}

</style>

<body>
  <?php
    // if ($id!=0)erreur(ERR_IS_NOT_CO);
    if (empty($_POST['nom']) && empty($_POST['prenom'])) {
      echo '<h1>Inscription</h1>';
      echo '<form method="post" action="inscription.php" enctype="multipart/form-data">
            <fieldset>
            <label for="nom">Nom  </label> <input name="nom" type="text" id="nom"  /> <br/> <br/> 
			<label for="prenom"> Prenom </label> <input name="prenom" type="text" id="prenom" /> <br/> <br />
            <label for="password"> Mot de Passe </label> <input type="password" name="password" id="password" /><br />  <br/>
            <label for="confirm">Confirmer le mot de passe </label> <input type="password" name="confirm" id="confirm" />    <br/>  <br/>
            <label for="email">Votre adresse Mail </label> <input type="email" name="email" id="email" /><br /> </fieldset> <br/> 
            <p><input type="submit" value="S\'inscrire" /></p></form></div></body></html>';
    }
    else {

      $erreur_mdp = NULL;
      $erreur_email_bis = NULL;
      $erreur_email_format = NULL;
      $i = 0;
      $nom = $_POST['nom'];
      $prenom = $_POST['prenom'];
      $password = $_POST['password'];
      $confirm = $_POST['confirm'];
      $email = $_POST['email'];
      $query = $pdo->prepare('SELECT COUNT(*) AS nbr FROM REDACTEUR WHERE nom = :nom AND prenom = :prenom');
      $query->bindValue(':nom',$nom,PDO::PARAM_STR);
      $query->bindValue(':prenom',$prenom,PDO::PARAM_STR);
      $query->execute();
      $query->CloseCursor();
      if($password != $confirm || empty($confirm) || empty($password)){
        $mdp_erreur = "Votre mot de passe et votre confirmation diffèrent, ou sont vides";
        $i++;
      }
      $query = $pdo->prepare('SELECT COUNT(*) AS nbr FROM REDACTEUR WHERE adressemail = :email');
      $query->bindValue(':email',$email,PDO::PARAM_STR);
      $query->execute();
      $email_free = ($query->fetchColumn()==0)?1:0;
      $query->CloseCursor();
      if(!$email_free){
        $email_erreur1 = "Votre adresse email est déjà utilisée par un membre";
        $i++;
      }
      if(!preg_match("#^[a-zA-Z0-9._-]+@[a-zA-Z0-9._-]{2,}\.[a-z]{2,4}$#",$email) || empty($email)){
        $email_erreur2 = "Votre adresse email n'a pas un format valide";
        $i++;
      }
      if($i == 0){
        echo'<h1>Inscription terminée</h1>';
        echo'<p>Bienvenue '.stripslashes(htmlspecialchars($_POST['prenom'])).' '.stripslashes(htmlspecialchars($_POST['nom'])).' vous êtes maintenant inscrit sur le forum</p>
        <p>cliquez <a href="menu.php">ici</a> pour revenir en arrière</p>';
        $query=$pdo->prepare('INSERT INTO REDACTEUR (nom,prenom,adressemail,motdepasse) VALUES (:nom,:prenom,:email,:password)');
        $query->bindValue(':nom',$nom,PDO::PARAM_STR);
        $query->bindValue(':prenom',$prenom,PDO::PARAM_STR);
        $query->bindValue(':email',$email,PDO::PARAM_STR);
        $query->bindValue(':password',$password,PDO::PARAM_STR);
        $query->execute();
        $_SESSION['nom'] = $nom;
        $_SESSION['prenom'] = $prenom;
        $_SESSION['id'] = $pdo->lastInsertId();
        $query->CloseCursor();
      }
      else {
        echo'<h1>Inscription interrompue</h1>';
        echo'<p>Une ou plusieurs erreurs se sont produites pendant l\'inscription</p>';
        echo'<p>'.$i.' erreur(s)</p>';
        echo'<p>'.$mdp_erreur.'</p>';
        echo'<p>'.$email_erreur1.'</p>';
        echo'<p>'.$email_erreur2.'</p>';
        echo'<p>Cliquez <a href="inscription.php">ici</a> pour réessayer.</p>';
      }
    }
  ?>
</body>
</html>
