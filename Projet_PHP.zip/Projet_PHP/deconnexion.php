<?php
$id=(isset($_SESSION['id']))?(int)$_SESSION['id']:0;
$nom=(isset($_SESSION['nom']))?$_SESSION['nom']:'';
$prenom=(isset($_SESSION['prenom']))?$_SESSION['prenom']:'';
session_start();
session_destroy();
echo '<p>Vous êtes à présent déconnecté <br />
Cliquez ci-dessous pour revenir à la page d\'accueil
<a href="accueil.php"> Accueil </a>
</p>';
echo '</div></body></html>';
?>