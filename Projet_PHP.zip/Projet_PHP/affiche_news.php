<form method="post" action="affiche_news.php" enctype="multipart/form-data">
<select name='tri'>
    <option value='1'> Tri par date
    <option value='2'> Tri par theme
</select>
<p><input type="submit" value="Tri" /></p>
</form>

<?php
include 'login.php';
$requete ="SELECT *,DATE_FORMAT(datenews,'%d-%m-%Y à %H:%i') as date
FROM NEWS,THEME,REDACTEUR
WHERE REDACTEUR.idredacteur=NEWS.idredacteur
AND NEWS.idtheme = THEME.idtheme";

if(isset($_POST['tri'])){
  $tri = ceil($_POST['tri']);
}else{
  $result = $pdo->query($requete);
}
if($tri==1){
  $result = $pdo->query($requete." order by date desc ");
} else if($tri==2){
  $result = $pdo->query($requete." order by CAST(NEWS.idtheme as unsigned) asc ");
}

// order by CAST(NEWS.idtheme as unsigned) asc // ou desc// ou  // order by date desc
while ($row=$result->fetch()){
echo"<article>";
echo  $row ['description'] . " - " . $row ['titrenews'] . " - " . $row['datenews'] . "<br>";
echo  $row ['textenews'] . "<br />";
echo  " écrit par : " .  $row['prenom'] . " " . $row['nom'];
echo"</article><br>";

}
$result ->closeCursor();
?>