<?php
	$pdo = null;
	
	$error = null;
	$dbtype = 'mysql';
	$dbname = 'vaguenez1u_projet_php';
	$dbhost = 'infodb.iutmetz.univ-lorraine.fr';
	$dbuser = 'vaguenez1u_appli';
	$dbpass = '31603539';

    try {
      $dsn = "{$dbtype}:host={$dbhost};dbname={$dbname}";
      $pdo =  new PDO($dsn,$dbuser,$dbpass);
	  $pdo->query('SET NAMES utf8');
	  //echo "Connexion réussie !<br/>\n";
    }
		
	catch (PDOException $error) {
      print "Erreur !: " . $error->getMessage();
      die();
	}
?>
