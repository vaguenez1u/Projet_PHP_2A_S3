<?php
  session_start();
  include("login.php");
?>
<body>
  <?php
  print_r($_POST);
  echo'<h1>Ajout terminé</h1>';
  echo'<p>cliquez <a href="menu.php">ici</a> pour revenir en arriÃ¨re</p>';
  $query = $pdo->prepare("INSERT INTO NEWS (idtheme,titrenews,datenews,textenews,idredacteur)
  VALUES(?,?,now(),?,1)") ;
  $query->bindValue(1,$_POST['description'],PDO::PARAM_STR);
  $query->bindValue(2,htmlentities($_POST['titrenews']),PDO::PARAM_STR);
  $query->bindValue(3,htmlentities($_POST['texte']),PDO::PARAM_STR);
//  $query->bindValue(4,'1',PDO::PARAM_STR);
  $query->execute();
  $query->CloseCursor();
  ?>
</body>
</html>
