<p><form method="post" action="add_news.php" enctype="multipart/form-data">
                 <fieldset><legend>Ajout News : </legend>

          <label for="description">Thème de votre news : </label>
             <select name='description'>
			 
<?php
               include 'login.php';
              $requete = "Select * from THEME";
               $result = $pdo->query($requete);
              
               
               while($row = $result->fetch()){
				   echo '<option value="'.$row["idtheme"]  . '" > '. $row ["description"].'</option>';
               }
               $result ->closeCursor();
  
 ?> 
                </select> 
				 			
                  <label for="titrenews">* titre de votre News :</label> <input name="titrenews" type="text" id="titrenews"/><br />
                  <p>* texte de votre news : </p>
                  <textarea rows='32' cols='128' name='texte'></textarea><br><br>
                  <p><input type="submit" value="Ajouter une news : " /></p>
                </fieldset>
    </form></p>