<!--<html>
<head>
<title> Notre site de news </title>
<meta charset='UTF-8'/>

include("login.php"); 
include("affiche_news.php");

</head>
    
<body>
<h1>Bienvenue sur notre site de news !</h1>
<p> Actualités : </p>


$news=$pdo->query("SELECT textenews FROM NEWS");
while( $news1 = $news->fetch(PDO::FETCH_OBJ) )
{
        echo $news1->textenews. '<br>';
}
$news->closeCursor();



</body>
</html>
-->

<?php 
$titre = "Menu";

$id=(isset($_SESSION['id']))?(int)$_SESSION['id']:0;
$nom=(isset($_SESSION['nom']))?$_SESSION['nom']:'';
$prenom=(isset($_SESSION['prenom']))?$_SESSION['prenom']:'';

session_start();

  ?>
  <script language="javascript" type="text/javascript">
  function valider(){
    if (confirm("Souhaitez-vous vraiment vous deconnetez ?")){
      window.location.href="deconnexion.php"; return true;
    }
    else return false;
  }
  function connexion(){
    window.location.href="authentification.php";
  }
  function inscription(){
    window.location.href="inscription.php";
  }
  function ecriture(){
    window.location.href="form_news.php";
  }
  function redacteur(){
	  window.location.href="affiche_redacteur.php";
  }
  </script>
  <link rel="stylesheet" href="css/accueil.css"/>
  </head>
<body>
<nav>
    <ul>
      <li id = "logo"></li>
      <?php
        if (isset($_SESSION['id'])){
      echo '<li id = "ecriture"><a onclick="ecriture()">ECRIRE</a></li>
      <li id = "deconnexion"><a onclick="valider()">DECONNEXION</a></li>
	  <li id = "Redacteurs"><a onclick="valider()">Voir les rédacteurs</a></li>';
      echo '<li id = "profil">';
      echo $_SESSION["prenom"] . ' ' . $_SESSION["nom"];
      echo '</li>';}
        else {
      echo '<input type="submit" value="Connexion" id="connexion" <a onclick="connexion()" </a>
			<input type="submit" value="Inscription" id="inscription" <a onclick="inscription()" </a> 
			<input type="submit" value="Voir les redacteurs" id="Redacteurs" <a onclick="redacteur()" </a>
			';}
     ?>
    </ul>
  </nav>
<form method="post" action="accueil.php" enctype="multipart/form-data">
<select name='tri'>
    <option value='1'> Tri par date
    <option value='2'> Tri par theme
</select>
<p><input type="submit" value="Tri" /></p>
</form>
<br/> 
<?php
include 'login.php';
$requete = "SELECT *,DATE_FORMAT(datenews,'%d-%m-%Y &#224 %H:%i') as date
			FROM NEWS,THEME,REDACTEUR
			WHERE REDACTEUR.idredacteur=NEWS.idredacteur
			AND NEWS.idtheme = THEME.idtheme";

if(isset($_POST['tri'])){
  $tri = ceil($_POST['tri']);
}
else{
  $result = $pdo->query($requete);
}
if($tri==1){
  $result = $pdo->query($requete." order by datenews desc ");
} 
else if($tri==2){
  $result = $pdo->query($requete." order by CAST(NEWS.idtheme as unsigned) asc ");
}

echo '<br><br><br>';

while ($row=$result->fetch()){
echo"<article>";
echo  $row ['description'] . " - " . $row ['titrenews'] . " - " . $row['date'] . "<br>";
echo  $row ['textenews'] . "<br />";
echo  " écrit par : " .  $row['prenom'] . " " . $row['nom'];
echo"</article><br>";

}
$result ->closeCursor();
?>
</body>
</html>
