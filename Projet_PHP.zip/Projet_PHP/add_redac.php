<html>
<head>
  <?php include 'login.php'; ?>
</head>
<body>

<?php
print_r($_POST);
// if(isset($_POST['valider'])){requête... }
//list($nom,$prenom) = explode(' ',htmlentities($_POST['redacteur']);
//$motdepasse=htmlentities($_POST['password']);
$insert_stmt = $objPdo->prepare("INSERT INTO REDACTEUR (nom,prenom,motdepasse,adressemail) VALUES(:nom,:prenom,:motdepasse,:adressemail)"); // VALUES(:iden,:uneligne)
$insert_stmt->bindValue('nom',$nom,PDO::PARAM_STR) ;
$insert_stmt->bindValue('prenom',$prenom,PDO::PARAM_STR) ;
$insert_stmt->bindValue('motdepasse',$_POST['password'],PDO::PARAM_STR) ;
$insert_stmt->bindValue('adressemail',$_POST['email'],PDO::PARAM_STR) ;
if($motdepasse == $_POST['confirm']){
  $insert_stmt->execute() ;
}
else {
  echo "problème de saisie du mot de passe (*2)";
}
// strip_tags pour éviter les injections HTML, à mettre dans les $_POST(['Nom']) etc....
?>
</body>
</html>