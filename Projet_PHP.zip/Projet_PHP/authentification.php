<!--<html>
<head>
<title>Authentification</title>
</head>
<body>
<h1>Authentifier-vous en vous connectant à votre compte</h1>

include "affiche_utilisateur.php";


<form method="post" action="addSites.php">
<h1>Ajout d'un point de vente</h1>
Nom : <input type="text" size="15" name="nom"><br>
Prénom : <input type="text" size="15" name="prenom"><br>
Adresse mail : <input type="text" size="30" name="email"><br>
Mot de passe : <input type="text" size="30" name="mdp"><br>
<input type="submit" value="Connexion"/>
</form>
</body>
</html>
-->

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8" />
</head>
<style type="text/css">
fieldset { width:30%;
border-radius: 25px;
}
label {
	width:50%;
	display:block;
text-align:left;
}
input[type="submit"]
{
  display: inline-block;
  padding: 15px 25px;
  font-size: 24px;
  cursor: pointer;
  text-align: center;
  text-decoration: none;
  outline: none;
  color: #fff;
  background-color: #4286f4;
  border: none;
  border-radius: 15px;
  box-shadow: 0 9px #999;
}

input[type="submit"]:hover {background-color: #4286f4}

input[type="submit"]:active {
  background-color: ##4286f4;
  box-shadow: 0 5px #666;
  transform: translateY(4px);
}

</style>
<body>
<?php
  define('ERR_IS_CO','Vous ne pouvez pas accéder à cette page si vous êtes connecté');
  $id=(isset($_SESSION['id']))?(int)$_SESSION['id']:0;
  $nom=(isset($_SESSION['nom']))?$_SESSION['nom']:'';
  $prenom=(isset($_SESSION['prenom']))?$_SESSION['prenom']:'';
  session_start();
  include("login.php");


  function erreur($err='') 
  {
    $mess=($err!='')? $err:'Une erreur inconnue s\'est produite';
    exit('<p>'.$mess.'</p>
          <p>Cliquez <a href="menu.php">ici</a> pour revenir à la page d\'accueil</p></div></body></html>');
  }
  echo '<h1>Connexion</h1>';
  //if ($id!=0)
   // erreur(ERR_IS_CO);
  if (!isset($_POST['nom'])) 
  {
    echo '<form method="post" action="authentification.php">
    <fieldset>
    <p><label for="nom">Nom </label><input name="nom" type="text" id="nom" /><br /> <br/>
    <label for="prenom">Prenom </label><input name="prenom" type="text" id="prenom" /><br /> <br/>
    <label for="password">Mot de Passe </label><input type="password" name="password" id="password" /></p></fieldset>
    <p><input type="submit" value="Se connecter" /></p></form></div></body></html>';
  }
  else 
  {
    $message = '';
    if (empty($_POST['nom']) || (empty($_POST['prenom'])) || empty($_POST['password'])) 
	{
      $message = '<p>une erreur s\'est produite pendant votre identification.
                  Vous devez remplir tous les champs</p>
                  <p>Cliquez <a href="authentification.php">ici</a> pour revenir</p>';
    }
    else 
	{
      $query = $pdo->prepare('SELECT idredacteur, nom, prenom, adressemail, motdepasse FROM REDACTEUR WHERE nom = :nom AND prenom = :prenom');
      $query->bindValue(':nom',$_POST['nom'],PDO::PARAM_STR);
      $query->bindValue(':prenom',$_POST['prenom'],PDO::PARAM_STR);
      $query->execute();
      $data=$query->fetch();
	  
      if ($data['motdepasse'] == $_POST['password']) 
	  {
        $_SESSION['id'] = $data['idredacteur'];
        $_SESSION['nom'] = $data['nom'];
        $_SESSION['prenom'] = $data['prenom'];
        $message = '<p>Bienvenue '.$data['prenom'].' '.$data['nom'].', vous êtes bien connecté</p>
                    <P>Cliquez ci-contre pour revenir à la page d\'accueil	
					<a href="accueil.php">Accueil</a>
					</p>';
      }
      else 
	  {
        $message = '<p>Une erreur s\'est produite pendant votre identification.<br /> Le mot de passe ou le nom entré n\'est pas correct.</p>
                    <p>Cliquez <a href=accueil.php">ici</a> pour revenir à la page d\'accueil</p>';
      }
      $query->CloseCursor();
    }
    echo $message.'</div></body></html>';
  }
?>


