<html>
<head>
<?php
	include "login.php";
?>
<title>Affichage rédacteurs</title>
</head>
<body>
<table border="1" cellspacing="1" cellspadding="1">
<thead>
<tr>
<th>Id</th>
<th>Nom</th>
<th>Prenom</th>
<th>Adresse mail</th>
</tr>
</thead>
<tbody>
<?php
$result = $pdo->query('select * from REDACTEUR') ;
while ($row=$result->fetch())
{
	echo '<tr>';
	echo '<td>' . $row ['idredacteur'] . "</td><td>" . $row ['nom'] .  "</td><td>" . $row ['prenom'] . "</td><td>" . $row ['adressemail'] . "</td>";	
	echo '</tr>';
}
$result->closeCursor() ;

?>
</tbody>
</table>
</body>
</html>